@extends('layouts.admin')

@section('content')

<div class="container">
    <h3>{{$form->name }}</h3>
    <br>
    <form method="POST" action= "{{route ('questionstore', $form->id) }}">
        @csrf
        <input type="hidden" name="id" value="{{ $form->id }}">
        

    <div class="form-wrapper">
        <h2 style="text-align: center;">Bienvenido, adelante podrás crear tu nuevo formulario</h2>
        <Br>

        <!-- Default 'Caja de texto' element -->
        <div id="formElements">
            <div class="input-container">
                <input type="text" class="input-box" placeholder="Caja de texto" name="que[]">
                <input type="text" class="input-box" placeholder="Respuesta de texto" value="text" name="quer[]" readonly="true">
                <button class="remove-btn">x</button>
            </div>
        </div>

        <!-- Green '+' button to add another element -->
        <div class="add-element-btn" id="addElementBtn">
            <i class="fas fa-plus"></i> Agregar otro elemento
        </div>

        <!-- Menu dividido en dos partes -->
        <div class="add-element-menu" id="elementMenu">
            <div class="menu-left">
                <div class="menu-option">
                    <button class="btn btn-light" id="selectTextBox">Caja de texto</button>
                </div>
                <div class="menu-option">
                    <button class="btn btn-light" id="selectImage">Imagen</button>
                </div>
            </div>
            <div class="menu-right disabled" id="responseOptions">
                <div class="menu-option">
                    <button class="btn btn-light" id="responseText">Caja de texto</button>
                </div>
                <div class="menu-option">
                    <button class="btn btn-light" id="responseMultipleChoice">Selección múltiple</button>
                </div>
            </div>
        </div>

        <!-- Confirmation buttons for creating or deleting the form -->
        <div class="centered-buttons">
            <button type="submit" class="btn btn-success">Crear formulario</button>
            <button id="borrarForm" class="btn btn-danger" >Borrar formulario</button>
                        <a href="{{ route('forms.index') }}" class="btn btn-danger">Cancel</a>
        </div>
    </div>

    </form>
@endsection

