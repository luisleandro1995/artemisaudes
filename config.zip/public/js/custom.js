/*USER TYPES*/

function confirmarBorrado() {
    return confirm('¿Seguro que quieres proceder a eliminar?');
    
}


/**QUESTIONS */



// Toggle the menu visibility
document.getElementById('addElementBtn').addEventListener('click', function(e) {
    e.preventDefault();
    var menu = document.getElementById('elementMenu');
    menu.classList.toggle('show-menu');
});

// Enable response options when selecting 'Caja de texto' or 'Imagen'
function enableResponseOptions() {
    document.getElementById('responseOptions').classList.remove('disabled');
}

// Option selection logic
document.getElementById('selectTextBox').addEventListener('click', function(e) {
    e.preventDefault();
    enableResponseOptions();
    clearResponseOptions(); // Clear previous event listeners
    document.getElementById('responseText').addEventListener('click', function(e) {
        e.preventDefault();
        addFormElement('text', 'text');
    });
    document.getElementById('responseMultipleChoice').addEventListener('click', function(e) {
        e.preventDefault();
        addFormElement('text', 'multipleChoice');
    });
});

document.getElementById('selectImage').addEventListener('click', function(e) {
    e.preventDefault();
    enableResponseOptions();
    clearResponseOptions(); // Clear previous event listeners
    document.getElementById('responseText').addEventListener('click', function(e) {
        e.preventDefault();
        addFormElement('image', 'text');
    });
    document.getElementById('responseMultipleChoice').addEventListener('click', function(e) {
        e.preventDefault();
        addFormElement('image', 'multipleChoice');
    });
});

// Function to add a new element pair (Question + Answer)
function addFormElement(questionType, answerType) {
    var formElements = document.getElementById('formElements');
    var inputContainer = document.createElement('div');
    inputContainer.className = 'input-container';

    // Create a question element (input or image placeholder)
    var questionInput;
    if (questionType === 'text') {
        questionInput = document.createElement('input');
        questionInput.type = 'text';
        questionInput.name= 'que[]';
        questionInput.className = 'input-box';
        questionInput.placeholder = 'Caja de texto';
    } else if (questionType === 'image') {
        questionInput = document.createElement('input');
        questionInput.type = 'file';
        questionInput.className = 'input-box';
        questionInput.accept = 'image/*';  // Para asegurarse de que solo se puedan subir imágenes
    }

    // Create an answer element (text or multiple-choice)
    var answerInput;
    if (answerType === 'text') {
        answerInput = document.createElement('input');
        answerInput.type = 'text';
        answerInput.name = 'quer[]';
        answerInput.value = 'text';
        answerInput.className = 'input-box';
        answerInput.placeholder = 'Respuesta de texto';
        answerInput.readOnly = 'true';
    } else if (answerType === 'multipleChoice') {
        answerInput = document.createElement('select');
        answerInput.className = 'input-box';
        answerInput.type = 'text';
        answerInput.name = 'quer[]';
        answerInput.value= 'Si';
        answerInput.innerHTML = '<option value="Si" selected>Si</option><option value="No">No</option>';
        answerInput.disabled = 'true';


        let answerInput2 = document.createElement('input');
        answerInput2.type = 'hidden';
        answerInput2.name = 'quer[]';
        answerInput2.value = 'select';
        
        inputContainer.appendChild(answerInput2);
    
    }

   
    var removeBtn = document.createElement('button');
    removeBtn.className = 'remove-btn';
    removeBtn.innerText = 'x';

    // Append both question and answer to the form
    inputContainer.appendChild(questionInput);
    inputContainer.appendChild(answerInput);
    inputContainer.appendChild(removeBtn);
    formElements.appendChild(inputContainer);

    removeBtn.addEventListener('click', function() {
        formElements.removeChild(inputContainer);
    });
}

// Function to clear previous event listeners
function clearResponseOptions() {
    var newResponseText = document.getElementById('responseText').cloneNode(true);
    var newResponseMultipleChoice = document.getElementById('responseMultipleChoice').cloneNode(true);
    document.getElementById('responseText').replaceWith(newResponseText);
    document.getElementById('responseMultipleChoice').replaceWith(newResponseMultipleChoice);
}

// Confirm form creation or deletion
//function confirmCreateForm() {
    //if (confirm("¿Seguro que desea crear el formulario?")) {
        //alert("Formulario creado con éxito");
//}
//}

document.getElementById('borrarForm').addEventListener('click',function(e){

    e.preventDefault();

    if (confirm("¿Seguro que desea borrar el formulario?")) {
        document.getElementById('formElements').innerHTML = ''; // Clears the form
        alert("Formulario borrado con éxito");
    }
});
