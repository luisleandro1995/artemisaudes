<?php

namespace App\Http\Controllers;


use App\Http\Requests\FormsRequest;
use App\Http\Requests\QuestionRequest;
use Illuminate\Support\Facades\Hash;
use App\Models\User; 
use App\Models\Dependency; 
use App\Models\WorkSpace; 
use App\Models\Form;
use App\Models\Question;


class FormController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }


    public function index()
    {
        try
        {
            $forms = Form::orderBy('id','desc')->paginate(5);
            return view('admin/forms/index', ['forms' =>$forms]) ;
        }
        catch(\Exception $e)
        {
            return view ('welcome');
            

        }
    }

    public function create()
    {
        try
        {
            $user = User::orderBy('id')->get();
            $dependencies = Dependency::orderBy('id')->get();
            $wss = WorkSpace::orderBy('id')->get();

            return view('admin/forms/create', ['users' => $user,
                                               'dependencies' => $dependencies,
                                               'wss' => $wss,

        ]);
        }
        catch(\Exception $e)
        {
            return view ('welcome');
            

        }
    }

        
    public function store(FormsRequest $request)
    {
        try
        {
           $form = new Form($request->all());
           $form->state = "activo";
           $form->save();

           return redirect()->route('forms.index');
        }
        catch(\Exception $e)
        {
            return view ('welcome');
            

        }
    }

    public function show($form)
    {
        try
        {
           $vform = Form::find($form);
               $user = User::orderBy('id')->get();
               $dependencies = Dependency::orderBy('id')->get();
               $wss = WorkSpace::orderBy('id')->get();
               $questions = Question::where('form_id', $vform->id)->get();
                
            if($vform)
            {
                return view('admin/forms/view', ['form' => $vform,
                    'users' => $user,
                'dependencies' => $dependencies,
                'wss' => $wss,
                'questions' => $questions
            ]);

            }
            else
            {
                return view ('admin/forms/index');
            }
        }
        catch(\Exception $e)
        {
            return view ('welcome');
            

        }
    }

    public function edit($form)
    {
        try
        {
           $vform = Form::find($form);

           $user = User::orderBy('id')->get();
           $dependencies = Dependency::orderBy('id')->get();
           $wss = WorkSpace::orderBy('id')->get();
          

        if($vform)
        {
            return view('admin/forms/update', ['form' => $vform,
                                             'users' => $user,
                                             'dependencies' => $dependencies,
                                             'wss' => $wss
                                             ]);
 
        }
        else
        {
            return view ('admin/forms/index');
        }
        }
        catch(\Exception $e)
        {
            return view ('welcome');
            

        }
    }

    public function update(FormsRequest $request, $form)
    {
        try
        {
           $vform = Form::find($form);
           $vform->fill($request->all());
           $vform->save();

            return redirect()->route('forms.index');


        }
        catch(\Exception $e)
        {
            return view ('welcome');
            

        }
    }

    public function destroy($form)
    {
         try
        {
           $vform = Form::find($form);

           $vform->delete();
            
            return redirect()->route('forms.index');



        }
        catch(\Exception $e)
        {
            var_dump($e);
            die();
            //return view ('welcome');
            

        }
    }

     

    public function questions($form)
    {
        try
        {
            $vform = Form::find($form);

            return view('admin/forms/questions', ['form' => $vform,

        ]);
        }
        catch(\Exception $e)
        {
            return view ('welcome');
            

        }
    }

           
    public function questionstore(QuestionRequest $request)
    {
        try
        {
           $data = $request->all();

           $formId= $data['id'];
           $questionsArray = $data['que'];
           $fieldsArray = $data['quer'];
           
           for ($i= 0; $i < count ($questionsArray); $i++)
           {
            $question = new Question();
            $question -> text_box = $questionsArray[$i];
            $question -> field_type = $fieldsArray [$i];
            $question -> form_id = $formId;
            $question->save();
           }


           return redirect()->route('forms.index');
        }
        catch(\Exception $e)
        {
            return view ('welcome');
            

        }
    }

}

