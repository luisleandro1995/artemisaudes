

<?php $__env->startSection('content'); ?>


<div class="container">
        <h3>Edit user type</h3>
        <form method="POST" action= "<?php echo e(route ('usertypes.update', $usertype->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <input type="hidden" name="id" value="<?php echo e($usertype->id); ?>">
        <div class="row">
                <div class="col-lg-12 mt-2">
                <label for="level">Level: </label>
                <input id="level" name="level" type="text" class="form-control" value=" <?php echo e(old('level', $usertype->level)); ?>" required>
                </div>
                <div class="col-lg-12 mt-5">
                    <input type="submit" class="btn btn-success" value="Update" />
                    <a href="<?php echo e(route('usertypes.index')); ?>" class="btn btn-danger">Cancel</a>
                </div>
            </div>
        </form>
    </div>
    <div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TrabajoGrado\Artemisa\artemisa\resources\views/admin/usertypes/update.blade.php ENDPATH**/ ?>