

<?php $__env->startSection('content'); ?>

<body>
    <div class="header">
        USERS CRUD
    </div>
    <div class="container mt-5">
        <h3>Users</h3>
        <div class="row mb-5">
            <div class="col-lg-12">
                <a href="<?php echo e(route ('users.create')); ?>" class="btn btn-primary float-end">New  users</a>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
            <table class="table table-striped">
                <tr>
                   <th>Name</th>
                   <th>Last Name</th>
                   <th>Document Type</th>
                   <th>Document Number</th>
                   <th>Email</th>
                   <th>State</th> 
                   <th>User Type</th>
                   <th>Actions</th> 
                </tr>


                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user-> name); ?></td>
            <td><?php echo e($user-> last_name); ?></td>
            <td><?php echo e($user-> document_type); ?></td>
            <td><?php echo e($user-> document_number); ?></td>
            <td><?php echo e($user-> email); ?></td>
            <td><?php echo e($user-> state); ?></td>
            <td>
                <?php ($userType= DB:: table('user_types')->where('id', $user->user_type_id)->get()); ?>
                <?php echo e($userType[0]->level); ?></td>

            <td>
                <a href="<?php echo e(route ('users.show', $user->id)); ?>" class="btn btn-primary">View</a>
                <a href="<?php echo e(route ('users.edit', $user->id)); ?>" class="btn btn-success">Edit</a>
                <form method="POST" action = "<?php echo e(route ('users.destroy', $user->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn btn-danger" onclick="return confirmarBorrado()" >Delete</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div><?php echo $users->render(); ?></div>
            </div>
        </div>
    </div>
</body>



<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TrabajoGrado\Artemisa\artemisa\resources\views/admin/users/index.blade.php ENDPATH**/ ?>