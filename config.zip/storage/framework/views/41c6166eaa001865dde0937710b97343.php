

<?php $__env->startSection('content'); ?>

<div class="container">
        <h3>New user type</h3>
        <form method="POST" action= "<?php echo e(route ('usertypes.store')); ?>">
        <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-lg-12 mt-2">
                <label for="level">Level: </label>
                <input id="level" name="level" type="text" class="form-control" required>
                </div>
                <div class="col-lg-12 mt-5">
                    <input type="submit" class="btn btn-success" value="Save" />
                    <a href="<?php echo e(route('usertypes.index')); ?>" class="btn btn-danger">Cancel</a>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TrabajoGrado\Artemisa\artemisa\resources\views/admin/usertypes/create.blade.php ENDPATH**/ ?>