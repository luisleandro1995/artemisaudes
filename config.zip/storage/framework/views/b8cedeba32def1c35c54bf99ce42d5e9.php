

<?php $__env->startSection('content'); ?>

<div class="container">
    <h3>New Work Space User</h3>
    <form method="POST" action="<?php echo e(route ('workspaceuser.store')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="row">


        <div class="col-lg-12 mt-2">
                <label for="work_space_id">Work Space: </label>
                <select class="form-select" id="work_space_id" name="work_space_id">
                <?php $__currentLoopData = $workspaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workspace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($workspace->id); ?>"><?php echo e($workspace->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-lg-12 mt-2">
                <label for="user_id">User: </label>
                <select class="form-select" id="user_id" name="user_id">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> <?php echo e($user->last_name); ?> <?php echo e($user->email); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            </div>

            <div class="col-lg-12 mt-5">
                <input type="submit" class="btn btn-success" value="Save" />
                <a href="<?php echo e(route('workspaceuser.index')); ?>" class="btn btn-danger">Cancel</a>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TrabajoGrado\Artemisa\artemisa\resources\views/admin/wsu/create.blade.php ENDPATH**/ ?>