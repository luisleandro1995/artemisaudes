

<?php $__env->startSection('content'); ?>

<div class="container">
        <h3>View user type</h3>
        <div class="row">
                <div class="col-lg-12 mt-2">
                <label for="level">Level: </label>
                <input id="level" name="level" type="text" class="form-control" value=" <?php echo e(old('level', $usertype->level)); ?>" readonly>
                </div>
                <div class="col-lg-12 mt-5">    
                    <a href="<?php echo e(route('usertypes.index')); ?>" class="btn btn-primary">Back</a>
                </div>
            </div>
        </div>
        <div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TrabajoGrado\Artemisa\artemisa\resources\views/admin/usertypes/view.blade.php ENDPATH**/ ?>