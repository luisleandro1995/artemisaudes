

<?php $__env->startSection('content'); ?>

<div class="container">
    <h3>View form</h3>
        <div class="row">
            <div class="col-lg-12 mt-2">
                <label for="name">Name: </label>
                <input id="name" name="name" type="text" class="form-control" value=" <?php echo e(old('name', $form->name)); ?>" readonly >
            </div>

            <div class="col-lg-12 mt-2">
                <label for="publication_date">Publication date: </label>
                <input id="publication_date" name="publication_date" type="date" class="form-control" value="<?php echo e(old('publication_date', $form->publication_date)); ?>" readonly>
            </div>

            <div class="col-lg-12 mt-2">
                <label for="end_date">End date: </label>
                <input id="end_date" name="end_date" type="date" class="form-control" value="<?php echo e(old('end_date', $form->end_date)); ?>" readonly>
            </div>

            <div class="col-lg-12 mt-2">
                <label for="user_id">User: </label>
                <select class="form-select" id="user_id" name="user_id" disabled>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>" <?php if($user->id ==$form->user_id): ?> selected="selected" <?php endif; ?> > <?php echo e($user->name); ?> <?php echo e($user->last_name); ?> - <?php echo e($user->email); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-lg-12 mt-2">
                <label for="dependency_id">Dependency: </label>
                <select class="form-select" id="dependency_id" name="dependency_id" disabled>
                <?php $__currentLoopData = $dependencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php ($faculty = DB::table('faculties')->where('id',$dependency->faculty_id)->get()); ?>
                <?php ($city= DB:: table('cities')->where('id', $dependency->city_id)->get()); ?>


                        <option value="<?php echo e($dependency->id); ?>" <?php if($dependency->id ==$form->dependency_id): ?> selected="selected" <?php endif; ?>  > <?php echo e($faculty[0]->name); ?> / <?php echo e($city[0]->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <div class="col-lg-12 mt-2">
                <label for="work_space_id">Work Space: </label>
                <select class="form-select" id="work_space_id" name="work_space_id " disabled>
                <?php $__currentLoopData = $wss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ws): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ws->id); ?>" <?php if($ws->id ==$form->work_space_id): ?> selected="selected" <?php endif; ?>  ><?php echo e($ws->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-lg-12 mt-2">
                <label for="work_space_id">Questions: </label>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <input type= "text" value="<?php echo e($question->text_box); ?>" readonly>
                    <?php if($question->field_type == "text"): ?>
                        <input type= "text" readonly>
                    <?php else: ?>
                        <select>
                            <option value ="Si">Si</option>
                            <option value ="No">No</option>
                        </select>
                    <?php endif; ?>
                    <br><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

            
            </div>

            <div class="col-lg-12 mt-5">
                <a href="<?php echo e(route('forms.index')); ?>" class="btn btn-danger">Back</a>
            </div>
        </div>
</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TrabajoGrado\Artemisa\artemisa\resources\views/admin/forms/view.blade.php ENDPATH**/ ?>