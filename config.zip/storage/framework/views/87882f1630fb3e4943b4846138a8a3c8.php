

<?php $__env->startSection('content'); ?>

<body>
    <div class="header">
        WORK SPACE USER
        </div>
    <div class="container mt-5">
        <h3>Work Space user</h3>
        <div class="row mb-5">
            <div class="col-lg-12">
                <a href="<?php echo e(route ('workspaceuser.create')); ?>" class="btn btn-primary float-end">New  Work Space</a>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
            <table class="table table-striped">
                <tr>
                   <th>Work Space Name</th>
                   <th>User email</th>
                   <th>Actions</th>

                </tr>

                <?php $__currentLoopData = $workspaceusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workspaceuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>

        <td>
                <?php ($ws= DB:: table('work_spaces')->where('id', $workspaceuser->work_space_id)->get()); ?>
                <?php echo e($ws[0]->name); ?></td>

            <td>
                <?php ($user= DB:: table('users')->where('id', $workspaceuser->user_id)->get()); ?>
                <?php echo e($user[0]->email); ?></td>

            <td>
                <form method="POST" action = "<?php echo e(route ('workspaceuser.destroy', $workspaceuser->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn btn-danger" onclick="return confirmarBorrado()" >Delete</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div><?php echo $workspaceusers->render(); ?></div>
            </div>
        </div>
    </div>
</body>



<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TrabajoGrado\Artemisa\artemisa\resources\views/admin/wsu/index.blade.php ENDPATH**/ ?>