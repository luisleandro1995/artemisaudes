

<?php $__env->startSection('content'); ?>

<body>
    <div class="header">
        FORMS CRUD
    </div>
    <div class="container mt-5">
        <h3>Forms</h3>
        <div class="row mb-5">
            <div class="col-lg-12">
                <a href="<?php echo e(route ('forms.create')); ?>" class="btn btn-primary float-end">New  form</a>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
            <table class="table table-striped">
                <tr>
                   <th>Name</th>
                   <th>Publication date</th>
                   <th>End date</th>
                   <th>State</th>
                   <th>User email</th>
                   <th>Dependency (Facultad/ Ciudad)</th>
                   <th>Work Space Name</th>
                   <th>Actions</th> 
                </tr>


                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>    
            <td><?php echo e($form-> name); ?></td>
            <td><?php echo e($form-> publication_date); ?></td>
            <td><?php echo e($form-> end_date); ?></td>
            <td><?php echo e($form-> state); ?></td>

            <td>
                <?php ($user= DB:: table('users')->where('id', $form->user_id)->get()); ?>
                <?php echo e($user[0]->email); ?></td>



            <td>
                <?php ($dependency = DB::table('dependencies')->where('id',$form->dependency_id)->get()); ?>
                <?php ($faculty= DB:: table('faculties')->where('id', $dependency[0]->faculty_id)->get()); ?>
                <?php ($city= DB:: table('cities')->where('id', $dependency[0]->city_id)->get()); ?>
                <?php echo e($faculty[0]->name); ?> / <?php echo e($city[0]->name); ?></td>


            <td>
                <?php ($ws= DB:: table('work_spaces')->where('id', $form->work_space_id)->get()); ?>
                <?php echo e($ws[0]->name); ?></td>

            <td>
                <a href="<?php echo e(route ('forms.show', $form->id)); ?>" class="btn btn-primary">View</a>
                <a href="<?php echo e(route ('forms.edit', $form->id)); ?>" class="btn btn-success">Edit</a>
                <a href="<?php echo e(route ('question', $form->id)); ?>" class="btn btn-primary">Add Questions</a>
                <form method="POST" action = "<?php echo e(route ('forms.destroy', $form->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn btn-danger" onclick="return confirmarBorrado()" >Delete</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div><?php echo $forms->render(); ?></div>
            </div>
        </div>
    </div>
</body>



<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TrabajoGrado\Artemisa\artemisa\resources\views/admin/forms/index.blade.php ENDPATH**/ ?>