

<?php $__env->startSection('content'); ?>

<body>
    <div class="header">
        WORK SPACES 
        </div>
    <div class="container mt-5">
        <h3>Work Spaces</h3>
        <div class="row mb-5">
            <div class="col-lg-12">
                <a href="<?php echo e(route ('workspaces.create')); ?>" class="btn btn-primary float-end">New  Work Space</a>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
            <table class="table table-striped">
                <tr>
                   <th>Name</th>
                   <th>User email </th>
                   <th>Actions</th>

                </tr>


                <?php $__currentLoopData = $workspaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workspace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($workspace-> name); ?></td>
            <td>
                <?php ($user= DB:: table('users')->where('id', $workspace->user_id)->get()); ?>
                <?php echo e($user[0]->email); ?></td>

            <td>
                <form method="POST" action = "<?php echo e(route ('workspaces.destroy', $workspace->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn btn-danger" onclick="return confirmarBorrado()" >Delete</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div><?php echo $workspaces->render(); ?></div>
            </div>
        </div>
    </div>
</body>



<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TrabajoGrado\Artemisa\artemisa\resources\views/admin/ws/index.blade.php ENDPATH**/ ?>